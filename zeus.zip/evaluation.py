import os
import time
import torch
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.decomposition import PCA
from sklearn.metrics import adjusted_rand_score, f1_score
from scipy.optimize import linear_sum_assignment
from zeus.utils import setup_seed, predict_clusters

# 引入你的数据集加载器
from dataset_loader import DatasetLoader
from zeus.configs import EvalDatasetType
from zeus.initialziation import initialize
from zeus.utils import predict_clusters  # 直接引入ZEUS的预测函数

def cluster_metrics(y_true, y_pred):
    """
    使用匈牙利算法计算聚类的 ACC 和 F1，并返回 ARI
    """
    ari = adjusted_rand_score(y_true, y_pred)
    
    # 匈牙利匹配
    D = max(y_pred.max(), y_true.max()) + 1
    w = np.zeros((D, D), dtype=np.int64)
    for i in range(y_pred.size):
        w[y_pred[i], y_true[i]] += 1
    row_ind, col_ind = linear_sum_assignment(w.max() - w)
    
    # 计算 Accuracy
    acc = sum([w[i, j] for i, j in zip(row_ind, col_ind)]) / y_pred.size
    
    # 将预测标签映射为真实标签以计算 F1 (Macro)
    mapping = {row_ind[i]: col_ind[i] for i in range(len(row_ind))}
    y_pred_mapped = np.array([mapping.get(y, y) for y in y_pred])
    f1 = f1_score(y_true, y_pred_mapped, average='macro')
    
    return ari, acc, f1

if __name__ == '__main__':
    # 1. 初始化模型和配置
    config, model = initialize()
    model.eval() # 设置为推理模式
    
    # 2. 选择你需要测试的数据集
    custom_dataset_funcs = [
        DatasetLoader.iris, 
        DatasetLoader.balance, 
        DatasetLoader.weather,
        DatasetLoader.hayes_roth, 
        DatasetLoader.phoneme, 
        DatasetLoader.monk_2,
        DatasetLoader.led7digit, 
        DatasetLoader.appendicitis, 
        DatasetLoader.ecoli,
        DatasetLoader.pima, 
        DatasetLoader.cars, 
        DatasetLoader.saheart,
        DatasetLoader.heart, 
        DatasetLoader.cleve, 
        DatasetLoader.cleveland,
        DatasetLoader.wine, 
        DatasetLoader.vowel, 
        DatasetLoader.penbased,
        DatasetLoader.vehicle, 
        DatasetLoader.hepatitis,
        DatasetLoader.segment,
        DatasetLoader.sonar, 
        DatasetLoader.air
    ]

    datasets = []
    print("正在加载并预处理自定义数据集...")
    for loader_func in custom_dataset_funcs:
        X, y, name, dim, num_classes = loader_func()
        
        # 预处理：标准化与降维
        X = StandardScaler().fit_transform(X)
        X = MinMaxScaler(feature_range=(-1, 1)).fit_transform(X)
        if config.use_pca and X.shape[1] > config.pca_dim:
            pca = PCA(n_components=config.pca_dim)
            X = pca.fit_transform(X)
            X = MinMaxScaler(feature_range=(-1, 1)).fit_transform(X)
            
        X_tensor = torch.tensor(X, dtype=torch.float32)
        y_tensor = torch.tensor(y, dtype=torch.int64)
        
        # 零填充对齐 ZEUS 的输入维度
        cur_dim = X_tensor.shape[1]
        if cur_dim < config.dim:
            padding = torch.zeros(X_tensor.shape[0], config.dim - cur_dim)
            X_tensor = torch.cat((X_tensor, padding), dim=1)
            
        datasets.append((X_tensor, y_tensor, name, num_classes))
        print(f"✅ 加载完成 [{name}]: 维度 {cur_dim}->{config.dim}, 类别数 {num_classes}")

    # 3. 开始 10 次独立重复实验
    runs = 10
    all_results = []
    print(f"\n🚀 开始执行 {runs} 次独立运行...")

    for i in range(runs):
        print(f"--- 正在执行第 {i+1}/{runs} 次运行 ---")
        setup_seed(2026 + i)
        for X_tensor, y_tensor, name, n_clusters in datasets:
            X_batch = X_tensor.unsqueeze(1).to(config.device)
            y_numpy = y_tensor.numpy()
            
            # 记录推理时间
            start_time = time.time()
            with torch.no_grad():
                output = model(X_batch)
                
            # 切片掉 ZEUS 内部预留的高斯中心 token，获取样本输出
            output = output[:-config.num_gaussians] 
            
            # 使用 K-Means 等解码器生成聚类标签
            y_pred = predict_clusters(
                output, n_clusters, config.device, 
                inf_method=config.inf_method, n_init=10
            ).squeeze(-1).detach().cpu().numpy()
            
            run_time = time.time() - start_time
            
            # 计算指标
            ari, acc, f1 = cluster_metrics(y_numpy, y_pred)
            
            all_results.append({
                'Dataset': name,
                'Run': i + 1,
                'ARI': ari,
                'ACC': acc,
                'F1': f1,
                'Time(s)': run_time
            })

    # 4. 保存详细结果 (每次运行的数据)
    df_raw = pd.DataFrame(all_results)
    raw_file = "zeus_10runs_detailed.csv"
    df_raw.to_csv(raw_file, index=False)
    print(f"\n📁 详细运行记录已保存至: {raw_file}")

    # 5. 计算均值和标准差，并直接格式化为论文表格形式 (Mean ± Std)
    agg_df = df_raw.groupby('Dataset').agg(['mean', 'std']).reset_index()
    
    summary_formatted = pd.DataFrame()
    summary_formatted['Dataset'] = agg_df['Dataset']
    summary_formatted['ARI'] = agg_df.apply(lambda row: f"{row[('ARI', 'mean')]:.4f} ± {row[('ARI', 'std')]:.4f}", axis=1)
    summary_formatted['ACC'] = agg_df.apply(lambda row: f"{row[('ACC', 'mean')]:.4f} ± {row[('ACC', 'std')]:.4f}", axis=1)
    summary_formatted['F1'] = agg_df.apply(lambda row: f"{row[('F1', 'mean')]:.4f} ± {row[('F1', 'std')]:.4f}", axis=1)
    summary_formatted['Time(s)'] = agg_df.apply(lambda row: f"{row[('Time(s)', 'mean')]:.4f} ± {row[('Time(s)', 'std')]:.4f}", axis=1)

    summary_file = "zeus_10runs_summary_for_latex.csv"
    summary_formatted.to_csv(summary_file, index=False)
    print(f"📊 汇总结果 (均值 ± 标准差) 已保存至: {summary_file}")
    
    # 打印最终结果预览
    print("\n论文表格数据预览：")
    print(summary_formatted.to_string(index=False))